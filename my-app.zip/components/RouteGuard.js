// import { useState, useEffect } from 'react';
// import { useRouter } from 'next/router';
// import { isAuthenticated } from '@/lib/authenticate';
// import { useAtom } from 'jotai';
// import { favouritesAtom, searchHistoryAtom } from '@/store';
// import { getFavourites, getHistory } from '@/lib/userData';

// const PUBLIC_PATHS = ['/login', '/', '/_error', '/register'];

// export default function RouteGuard(props) {
//     const router = useRouter();
//     const [authorized, setAuthorized] = useState(false);
//     const [favouritesList, setFavouritesList] = useAtom(favouritesAtom);
//     const [searchHistory, setSearchHistory] = useAtom(searchHistoryAtom);

//     async function updateAtoms() {
//         setFavouritesList(await getFavourites());
//         setSearchHistory(await getHistory());
//     }

    
//     useEffect(() => {
//         // on initial load - run auth check 
//         updateAtoms();
//         authCheck(router.pathname);

//         // on route change complete - run auth check 
//         router.events.on('routeChangeComplete', authCheck)

//         // unsubscribe from events in useEffect return function
//         return () => {
//             router.events.off('routeChangeComplete', authCheck);
//         }

//     }, []);

//     function authCheck(url) {
//         // redirect to login page if accessing a private page and not logged in 
//         const path = url.split('?')[0];
//         if (!isAuthenticated() && !PUBLIC_PATHS.includes(path)) {
//             setAuthorized(false);
//             router.push("/login");
//         } else {
//             setAuthorized(true);
//         }
//     }

//     return (
//       <>
//         {authorized && props.children}
//         {/* {props.children} */}
//       </>
//     )
// }
import { isAuthenticated } from '@/lib/authenticate';
import { getFavourites, getHistory } from '@/lib/userData';
import { favouritesAtom, searchHistoryAtom } from '@/store';
import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import { useAtom } from "jotai";

const PUBLIC_PATHS = ['/login', '/', '/_error', '/register'];

export default function RouteGuard(props) {
    const router = useRouter();
    const [authorized, setAuthorized] = useState(false);
    const [favouritesList, setFavouritesList] = useAtom(favouritesAtom)
    const [historyList, setHistoryList] = useAtom(searchHistoryAtom)
    
    
    useEffect(() => {
        updateAtoms();
        authCheck(router.pathname);

        router.events.on('routeChangeComplete', authCheck);

        return ()=>{
            router.events.off('routeChangeComplete', authCheck);
        }
    }, [authCheck, router.events, router.pathname, updateAtoms]);

    function authCheck(url) {
        const path = url.split('?')[0];
        if (!isAuthenticated() && !PUBLIC_PATHS.includes(path)) {
            setAuthorized(false);
            router.push('/login');
        } else {
            setAuthorized(true);
        }
    }
    
    async function updateAtoms() {
        setFavouritesList(await getFavourites());
        setHistoryList(await getHistory());
    }

    return <>
        {authorized && props.children}
    </>
}